# Dark World Shop

A modern e-commerce website for dark web monitoring services with wallet checkout functionality.

## Local Development

### Option 1: Python HTTP Server
```bash
# Python 3
python -m http.server 8000

# Python 2
python -m SimpleHTTPServer 8000
```
Then open: `http://localhost:8000`

### Option 2: Node.js HTTP Server
```bash
# Install http-server globally
npm install -g http-server

# Run the server
http-server -p 8000
```
Then open: `http://localhost:8000`

### Option 3: VS Code Live Server
1. Install the "Live Server" extension in VS Code
2. Right-click on `index.html`
3. Select "Open with Live Server"

## Features

- Product catalog with filtering
- Shopping cart with localStorage persistence
- Wallet checkout with multiple cryptocurrency support
- Proof of payment upload with Formspree integration
- Tawk.to live chat widget
- Fully responsive design
- Mobile-optimized interface

## Deployment

To deploy this site:

1. **Netlify**: Drag and drop the folder or connect to Git
2. **Vercel**: Import the project and deploy
3. **GitHub Pages**: Push to a repository and enable Pages
4. **Traditional Hosting**: Upload files via FTP

## Domain Setup

If you own `darkworldshop.com`:
1. Purchase/configure the domain
2. Point DNS to your hosting provider
3. Deploy the site files

## File Structure

```
DarkWeb/
├── index.html          # Home page
├── products.html       # Products catalog
├── features.html       # Features page
├── styles.css          # All styles
├── script.js           # All JavaScript functionality
├── cart-storage.json   # Cart storage (optional)
└── product/            # Product detail pages
    ├── 1/index.html
    ├── 2/index.html
    └── 3/index.html
```

## Configuration

- **Formspree**: Configured at `https://formspree.io/f/mdkbnlww`
- **Tawk.to**: Live chat widget included on all pages

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
